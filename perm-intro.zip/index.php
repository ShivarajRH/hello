<!DOCTYPE html>
	<head>
		<link href='http://lyfeon.com/fonts/font.css' rel='stylesheet' type='text/css'>
		<link href='http://lyfeon.com/css/search.css' rel='stylesheet' type='text/css'>
		<link href='http://lyfeon.com/css/onebar.css' rel='stylesheet' type='text/css'>
		<meta name="description" content="Permeative is the bangalore based leading mobile application developer serving enterprises with secure, powerful &amp; beautiful apps on popular platforms - iOS and Android. Get your free quote now." /> 
		<title>Permeative - Mobile Application Development - iOS & Android</title>
	
		<script type="text/javascript">
			 var _gaq = _gaq || [];
			 _gaq.push(['_setAccount', 'UA-22003974-1']);
			 _gaq.push(['_setDomainName', 'permeative.com']);
			 _gaq.push(['_setAllowLinker', true]);
			 _gaq.push(['_trackPageview']);

			 (function() {
			   var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			   ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			   var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			 })();
		</script>
		<style style="text/css">
			button {
				border: none;
				padding: 0.8%;
				border-radius: 1em;
				cursor: pointer;
				background-color: #d1d1d1;
				color: #000000;
				font-family: Roboto-Regular;
				font-size: 85%;
			}
			details summary{
				cursor:pointer;
				color:#d0d0d0;
			}
			details summary::-webkit-details-marker {
				color: #d0d0d0;
				font-size: 20px;
			}
			*:focus {
				outline: none;
			}
			.item_slid .text{
				color:#fff;
			}
		</style>
</head>

<body style="position:absolute;left:0%;background-color:#000000;color:#fff;">
	<div style="position:fixed;z-index: -99; width: 100%; height: 100%; opacity: 0.25;filter: alpha(opacity=25);-khtml-opacity: 0.25;-moz-opacity: 0.25; background-color:#000;background-size:100%;background-image:url('images/bg2.png');background-repeat:no-repeat;background-attachment:fixed;"></div>
	<div class="container item_slid" style="max-width:90%;left:5%;">
		<div class="content-meta" style="margin-top:2%;">	
			<div class="text" style="clear:both;">
				<span class="text content-title object1" style="font-size:500%;"><img src="images/permlogo.png" style="margin-right:2%;float:left;max-width: 20%!important; height: auto!important;"></img>Permeative</span></br><span class="text">Beautiful Design | Intense Engineering</span>
			</div>
		</div></br>
		<div style="clear:both">
			<div class="item-details text" style="height:11em;padding:3%;background-color:#d1d1d1;max-width:85%;opacity:0.75;filter: alpha(opacity=27);-khtml-opacity: 0.75;-moz-opacity: 0.75;">
				<h2 class="text" style="font-size:150%;color:#000000;">The Mobile Application Development Company. iOS & Android</h3>
				<p class="text" style="color:#000000;">Listed thrice in a row as 25 most promising tech companies in India by Silicon India.</br>Listed in top 20 mobile solution vendors.</br></br>Quick Call:&nbsp;&nbsp; &nbsp;&nbsp;Anil &nbsp;&nbsp;&nbsp;&nbsp; 91 779 556 6972 &nbsp;&nbsp;&nbsp;&nbsp; anil.taraka@permeative.com</span></p>
			</div>
		</div>
		<h2 class="text" style="clear:left; font-size:175%;"></br>Services Offered</h3>
		<div style="clear:both">
			<div style="float:left;padding-right:4%;line-height:150%;">
				<dt class="text "><span class="text" style="font-size:130%;">Design</span>
					<dd>Information Architecture Design</dd>
					<dd>Mobile Design</dd>
					<dd>User Experience</dd>
					<dd>User Interface</dd>
					<dd>Product Design</dd>
					<dd>Product Concept</dd>
				</dt></br>
				<dt class="text"><span class="text" style="font-size:130%;">Solutions</span>
					<dd>Local Business Solutions</dd>
					<dd>App Marketing Solutions</dd>
					<dd>Analytics</dd>
				</dt>
			</div>
			<div  style="float:left;padding-right:4%;line-height:150%;">
				<dt class="text"><span class="text" style="font-size:130%;">Development</span>
					<dd>Mobile Games</dd>
					<dd>Mobile Applications</dd>
					<dd>iOS (iPhone and iPad) Apps and Games</dd>
					<dd>Android Apps and Games</dd>
					<dd>Windows 8 Apps and Games</dd>
					<dd>Web Applications</dd>
					<dd>HTML5 and CSS3</dd>
					<dd>PHP & JavaScript</dd>
					<dd>Database Architecture</dd>
					<dd>Product Development</dd>
				</dt>
			</div>
			<div  style="float:left;line-height:150%;">
				<dt class="text"><span class="text" style="font-size:130%;">Marketing</span>
					<dd>Campaigns</dd>
					<dd>ROI Analysis</dd>
					<dd>Social Media Marketing</dd>
					<dd>Strategy and Planning</dd>
					<dd>Search Engine Optimization (SEO)</dd>
					<dd>Search Engine Marketing (SEM)</dd>
					<dd>Display Campaigns</dd>
					<dd>E-Mail Marketing</dd>
					<dd>Advertising Solutions</dd>
					<dd>Marketing and Analytics Solutions</dd>
					<dd>Customer Outreach</dd>
				</dt>
			</div>
		</div>
		<p class="text content-text" style="clear:both;">	</br></br></br> <h2 class="text" style="font-size:175%;">Our Partners</h3>
			<img class="content-image object 15" style="padding:0%;margin-left:1%;max-width: 90%!important;height: auto!important;text-align: center;margin-bottom: 2%;opacity:0.75;filter: alpha(opacity=27);-khtml-opacity: 0.75;-moz-opacity: 0.75;" src="images/partners.png"></img>
		</p>
		<h2 class="text" style="font-size:175%;"></br></br>Upcoming Products</h3>
		<div class="content" style="clear:both;">
			<div class="item-data">
				<div class="item-details text" style="height:22em;padding-left:6%;background-color:#d1d1d1;margin-bottom:3%;max-width:85%;opacity:0.75;filter: alpha(opacity=27);-khtml-opacity: 0.75;-moz-opacity: 0.75;">
					<li class="img_thamb icon_img" style="height:20em;width:23%;color:#000;">
						<img class="object6" src="images/appchomp.png"></br>
						AppChomp helps discover apps across different platforms</br></br>
						<span class="remark" style="padding:6%;"><a href="http://lyfeon.com/appchomp">Go to App</a></span>
						<span class="remark" style="padding:6%;"><a href="">Soon on iPad</a></span>
					</li>
					<li class="img_thamb icon_img" style="height:20em;width:23%;color:#000;">
						<img class="object6" src="images/360.png"></br>
						Get a distraction free content experience from hundreds of sources</br></br>
						<span class="remark" style="padding:6%;"><a href="http://lyfeon.com/360">Go to App</a></span>
						<span class="remark" style="padding:6%;"><a href="">Soon on iPad</a></span>
					</li>
					<li class="img_thamb icon_img" style="height:20em;width:23%;color:#000;">
						<img class="object6" src="images/weather.png"></br>
						Weather presented as you need it, when you need it</br></br>
						<span class="remark" style="padding:6%;"><a href="http://lyfeon.com/weather">Go to App</a></span>
						<span class="remark" style="padding:6%;"><a href="">Soon on iPad</a></span>
					</li>					
				</div>
			</div>
			<div class="article">
				<div class="" style="padding-left:6%;padding-right:1%;">
					<div class="text" style="clear:both;">
						<span class="text content-title object1" style="font-size:160%;"><img src="images/images/lyfeondev.png" style="float:left;max-width: 3%!important; height: auto!important;"></img>&nbsp;LyfeOn Development Platform</span></br></br><span class="text">Create apps in minutes quickly and easily using LyfeOn Development Platform. </br>Download LyfeOn SDK's or libraries for iOS and Android or simply start with API's. </br>Register on <a href="http://lyfeon.com/developers">http://lyfeon.com/developers</a> and get started.</span>
					</div>
				</div>
				</br></br>
				<div class="" style="padding-left:6%;padding-right:1%;">
					<div class="text" style="clear:both;">
						<span class="text content-title object1" style="font-size:160%;"><img src="images/lyfeon.png" style="float:left;max-width: 3%!important; height: auto!important;"></img>&nbsp;LyfeOn for Business</span></br></br><span class="text">Reach your customers quickly with your products and services.</br>Get analytics on how your customers are responding and interacting with your brand/product/service.</br>Get started quickly on <a href="http://lyfeon.com/business">http://lyfeon.com/business</a></br></br></br></br></span></br>
					</div>
				</div>
			</div>
		</div>
		<div style="clear:both;">
			<h2 class="text" style="font-size:175%;float:left;">Reach Us&nbsp;&nbsp;&nbsp;&nbsp;</h3>
			<div class="icons" style="float:left;">
				<a href="https://plus.google.com/u/0/114172925467895001920?prsrc=3" alt="google+" >
					<img src="images/plus.png" width="35px" height="35px"/>
				</a>&nbsp;&nbsp;
				<a href="https://www.facebook.com/PermeativeTechnologies" alt="facebook" >
					<img src="images/fb.png" width="32px" height="32px"/>
				</a>&nbsp;&nbsp;
				<a href="https://twitter.com/#!/PermeativeTech" alt="twitter" >
					<img src="images/twitter.png" width="35px" height="35px"/>
				</a>&nbsp;&nbsp;
				<a href="http://www.linkedin.com/company/permeative-technologies-pvt-ltd" alt="linkedin" >
					<img src="images/linkedin.jpg" width="35px" height="35px"/>
				</a>&nbsp;&nbsp;
				<a href="http://pinterest.com/permeative/" alt="pinterest" >
					<img src="images/pinterest.png" width="32px" height="32px"/>
				</a>&nbsp;&nbsp;
			</div></br>
		</div>
		<div class="contact" style="clear:both;">
			<address class="text">Email: <a href="mailto:contact@permeative.com">contact@permeative.com</a></address></br>
			Business & Sales: </br><h3>Anil</h3>Phone: (91) 779 556 6972 </br>Email: <a href="mailto:anil.taraka@permeative.com">anil.taraka@permeative.com</a>
		</div>
		<div class="contact" style="clear:both;"> <br></br>
			<details open>
				<summary>Our Locations &raquo; </summary>
				<div class="" style="float:left; padding-right:12%;">
					<div class="text"><h3>Business Center</h3>38 Citation Drive, Freehold</br>New Jersey, US, 07728 </br>Phone: +1 248 256 5085</div>
				</div>
				<div class="bangalore" style="float:left; padding-right:12%;">
					<div class="text"><h3>Development Labs</h3>#4/5, Khykha Court, 1st Cross, Hosur Road </br>Madiwala, Bangalore-560068, India </br>Phone: +91 779 556 6972</div>
				</div>
				<div class="sydney">
					<div class="text"><h3>Business Center</h3>3/211 Hawkesbury Road,Westmead, </br>NSW-2145, Sydney, Australia</br>Phone: 028 677 8339</div>
				</div>
			</details>
		</div></br></br>
		<h2 class="text" style="font-size:175%; clear:both;"></br>About Us</h3>
		<p class="text" style="line-height:150%; max-width:60em;">Permeative is the leading mobile application development company with business offices in New Jersey (USA), Victoria (Australia) and development center in Bangalore (India).</p>
        <details open>
			<summary>What we do &raquo; </summary>
			<p  style="line-height:150%; max-width:60em;">We are developing applications for iPhone, Android, for more than since last five years with more than 600 apps developed so far. </br>We have award winning developers and designers and our apps are often featured prominently in App Store. </br>Our esteemed partners include Philips, Samsung, Sling Media and Cascadia.</p>
			<p class="text"  style="line-height:150%; max-width:60em;">Permeative can help you with your app development efforts by providing resources on contract for your short term and long term requirements. </br>You can either outsource a project for development, or you can also hire resource to work from your office premises.</p>
			<p class="text"  style="line-height:150%; max-width:60em;">Feel free to reach us for  your app requirements and for any of your questions and concerns. </p>
			<p class="text" style="line-height:150%; max-width:60em;"><a href="http://permeative.com/"><button>Visit Website</button></a> for more details</p>
		</details>
		<h2 class="text" style="font-size:175%; clear:both;"></br></br>Jobs</h3>
		<p class="text" style="line-height:150%; max-width:60em;">We always thought LyfeOn as place that brings together smart, talented people from a diversity of backgrounds where you could bring your whole self to work.</br>You are free to work on the project you like with the team you like.</br>We think employee freedom leads to better productiveness.</p><p class="text" style="line-height:150%; max-width:60em;">Join us: Apply at <a href="email:hr@permeative.com">hr@permeative.com</a></p>
		<h2 class="text" style="font-size:175%; clear:both; max-width:60em;"></br></br>Education</h3>
		<p class="text" style="line-height:150%; max-width:60em;">Future is now and we are glad to announce the new initiative �Learning @ Permeative�, to help aspirants learn about mobile eco system, app development and the skill-set they require to succeed in this new connected world.
</p><p class="text" style="line-height:150%; max-width:60em;"><a href="http://permeative.com/learning/"><button>Click Here</button></a> for more details</p>
		
		</br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br></br>
            

		
	</div>
</body>